# Minimal Flask app

The code in this sample comes from the tutorial that begins on https://docs.microsoft.com/en-us/azure/developer/python/tutorial-deploy-app-service-on-linux-01. Specifically, it's the code described on 
https://docs.microsoft.com/en-us/azure/developer/python/tutorial-deploy-app-service-on-linux-02?tabs=cmd#option-3-create-a-minimal-flask-app.